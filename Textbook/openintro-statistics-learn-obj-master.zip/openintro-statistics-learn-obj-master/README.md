# openintro-statistics-learning-objectives

This repo contains chapter-by-chapter learning objectives for 
[OpenIntro Statistics](https://www.openintro.org/stat/textbook.php?stat_book=os).

PDF files can also be found [here](https://www.openintro.org/stat/textbook.php?stat_book=os).